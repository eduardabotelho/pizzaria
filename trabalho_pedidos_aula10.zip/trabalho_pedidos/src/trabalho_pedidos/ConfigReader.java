package trabalho_pedidos;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;

public class ConfigReader { // ler o arquivo de configurações e tornar possível a forma genérica de se trabalhar com os dados nele

	public HashMap<String, String> read() throws IOException {
		FileInputStream fis = new FileInputStream("resources/config.properties");
		InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
		BufferedReader buffer = new BufferedReader(isr);
		
		try {
		String line = null;
		HashMap<String, String> result = new HashMap<>();
		while ((line = buffer.readLine()) != null) {
			String info[] = line.split("=");
			String key = info[0]; 
			String value = info[1]; 
			result.put(key, value);
		
		}return result;
		}finally{
			buffer.close();
			fis.close();
		}
	}
}
