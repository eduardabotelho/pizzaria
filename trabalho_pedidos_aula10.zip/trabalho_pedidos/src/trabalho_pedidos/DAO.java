package trabalho_pedidos;

import java.util.List;

public interface DAO {
	
	List<Pedido> getAll() throws Exception;

	void insert(Pedido value) throws Exception;

	void update(Pedido value) throws Exception;

	void delete(Pedido value) throws Exception;

	void write(List<Pedido> lista) throws Exception;


}