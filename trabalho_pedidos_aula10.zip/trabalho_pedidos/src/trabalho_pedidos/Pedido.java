package trabalho_pedidos;

public class Pedido {
	int mesa;
	String sabor;

	public Pedido() {
	}

	public Pedido(int m) {
		this.mesa = m;
	}

	public Pedido(int m, String s) {
		this.mesa = m;
		this.sabor = s;
	}

	public int getMesa() {
		return mesa;
	}

	public void setMesa(int me) {
		this.mesa = me;
	}

	public String getSabor() {
		return sabor;
	}

	public void setSabor(String sa) {
		this.sabor = sa;
	}
}
