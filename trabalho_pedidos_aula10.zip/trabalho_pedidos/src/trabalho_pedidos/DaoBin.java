package trabalho_pedidos;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.List;

public class DaoBin implements DAO {
	
	private HashMap<String, String> config;
	private String filename;
	private String html;
	
	public DaoBin() throws IOException {// coloca no construtor p q possa usar no restante dos metodos
		ConfigReader configReader = new ConfigReader();
		config = configReader.read();
		filename = config.get("file");
		config.get("delimiter");
		html = config.get("outputHtml");
	}

	private void writeAll(List<Pedido> list) throws FileNotFoundException, IOException {
		FileOutputStream fos = new FileOutputStream(filename);
		ObjectOutputStream oos = new ObjectOutputStream(fos);

		try {
			oos.writeObject(list);
		} finally {
			oos.close();
			fos.close();
		}
	}

	@Override
	public List<Pedido> getAll() throws Exception {
		FileInputStream fis = new FileInputStream(filename);
		ObjectInputStream ois = new ObjectInputStream(fis);
		try {
			Object objeto = ois.readObject(); // le o o objeto
			@SuppressWarnings("unchecked")
			List<Pedido> list = (List<Pedido>) objeto;
			return list;
		} finally {
			ois.close();
			fis.close();
		}
	}

	@Override
	public void insert(Pedido value) throws Exception {
		// le o que está no arquivo
		List<Pedido> list = getAll();
		list.add(value); // adiciona o valor novo

		writeAll(list);
	}

	@Override
	public void update(Pedido value) throws Exception {
		// le o que está no arquivo
		List<Pedido> list = getAll();
		list.add(value); // adiciona o valor novo

		int index = 0;
		for (Pedido base : list) {
			if (base.getMesa() == value.getMesa()) {
				list.set(index, value);
			}
			index += 1;
		}
		writeAll(list);
	}

	@Override
	public void delete(Pedido value) throws Exception {

		List<Pedido> list = getAll();

		int index = 0;
		while (index < list.size()) {
			if (list.get(index).getMesa() == value.getMesa()) {
				list.remove(index);
				break; // qnd encontra já interrompe
			}

			index += 1;
		}

		writeAll(list);
	}

	public void write(List<Pedido> lista) throws Exception {
		FileWriter writer = new FileWriter(html);
		BufferedWriter buffer = new BufferedWriter(writer);
		try {

			buffer.write("<html>");
			buffer.newLine();

			buffer.write("<head><meta charset='utf-8'></head>");
			buffer.newLine();

			buffer.write("<body>");
			buffer.newLine();

			buffer.write("<table border='1'>");
			buffer.newLine();

			buffer.write("<tr><td>Mesa</td><td>Sabor</td></tr>");
			buffer.newLine();

			for (Pedido p : lista) {
				buffer.write("<tr><td>" + p.getMesa() + "</td><td>" + p.getSabor() + "</td></tr>");
				buffer.newLine();
			}
			buffer.write("</table>");
			buffer.newLine();

			buffer.write("</body>");
			buffer.newLine();

			buffer.write("</html>");
			buffer.newLine();

		} finally {
			buffer.close();
			writer.close();
		}
	}

}
