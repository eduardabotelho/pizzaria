package trabalho_pedidos;

import java.util.List;

public class Main {
	public static void main(String[] args) throws Exception {

		DAO daoPedido = new Factory().getDAO(Pedido.class, "Bin");

		// INSERT
		daoPedido.insert(new Pedido(1, "portuguesa"));
		daoPedido.insert(new Pedido(2, "calabresa"));
		daoPedido.insert(new Pedido(3, "hahah"));

		// UPDATE

		// GETALL
		List<Pedido> pedidos = daoPedido.getAll();
		for (Pedido p : pedidos) {
			Pedido pedido = (Pedido) pedidos;
			System.out.println(pedido.getMesa() + " " + pedido.getSabor());
		}

		// DELETE
		daoPedido.delete(new Pedido(2, "calabresa"));

		System.out.println("FIM");
	}
}