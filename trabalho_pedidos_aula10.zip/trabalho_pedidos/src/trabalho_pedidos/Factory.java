package trabalho_pedidos;

public class Factory {

	@SuppressWarnings("deprecation")
	DAO getDAO(Class<? extends Pedido> klass, String type) throws Exception {
		String className = klass.getName() + type;
		Class<?> name = Class.forName(className); 
		return (DAO)name.newInstance();
	}
}